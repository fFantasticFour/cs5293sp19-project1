# -*- coding: utf-8 -*-
# Brandon Wolfe's main.py for project1 in cs5293

import argparse
import glob
import nltk
import spacy
import numpy as np
from spacy.matcher import PhraseMatcher
from spacy.matcher import Matcher
import os

#List of gendered terms taken from https://www.oreilly.com/library/view/applied-text-analysis/9781491963036/ch01.html
#Note: no other parts of the above-referenced code were used in this solution

MALE = 'male'
FEMALE = 'female'
UNKNOWN = 'unknown'
BOTH = 'both'

MALE_WORDS = set([
    'guy','spokesman','chairman',"men's",'men','him',"he's",'his',
    'boy','boyfriend','boyfriends','boys','brother','brothers','dad',
    'dads','dude','father','fathers','fiance','gentleman','gentlemen',
    'god','grandfather','grandpa','grandson','groom','he','himself',
    'husband','husbands','king','male','man','mr','nephew','nephews',
    'priest','prince','son','sons','uncle','uncles','waiter','widower',
    'widowers'
])

FEMALE_WORDS = set([
    'heroine','spokeswoman','chairwoman',"women's",'actress','women',
    "she's",'her','aunt','aunts','bride','daughter','daughters','female',
    'fiancee','girl','girlfriend','girlfriends','girls','goddess',
    'granddaughter','grandma','grandmother','herself','ladies','lady',
    'lady','mom','moms','mother','mothers','mrs','ms','niece','nieces',
    'priestess','princess','queens','she','sister','sisters','waitress',
    'widow','widows','wife','wives','woman'
])

def main(args):

    nlp = spacy.load('en')
    
    for f in glob.glob(args.input):
        print(f)
        document = open(f).read()
        document = nlp(document)

        toredact = []
        if args.names: 
            toredact = [(e.text, e.start_char, e.end_char, e.label_) for e in filter(lambda w: w.label_ == 'PERSON', document.ents)]

        if args.dates:
            toredact += [(e.text, e.start_char, e.end_char, e.label_) for e in filter(lambda w: w.label_ == 'DATE', document.ents)]

        if args.addresses:
            toredact += [(e.text, e.start_char, e.end_char, e.label_) for e in filter(lambda w: w.label_ == 'LOC', document.ents)]

        if args.gender:
            female_matcher = PhraseMatcher(nlp.vocab)
            male_matcher = PhraseMatcher(nlp.vocab)
            female_patterns = [nlp.make_doc(text) for text in FEMALE_WORDS]
            male_patterns = [nlp.make_doc(text) for text in MALE_WORDS]

            female_matcher.add('FemaleList', None, *female_patterns)
            female_matches = female_matcher(document)
            toredact += [(document[start:end].text,start,end,'FEMALE') for match_id, start, end in female_matches]
            male_matcher.add('MaleList', None, *male_patterns)
            male_matches = male_matcher(document)
            toredact += [(document[start:end].text,start,end,'MALE') for match_id, start, end in male_matches]

        if args.phones:
            matcher = Matcher(nlp.vocab)
            pattern = [{'ORTH': '('}, {'SHAPE': 'ddd'}, {'ORTH': ')'}, {'SHAPE': 'ddd'},
                    {'ORTH': '-', 'OP': '?'}, {'SHAPE': 'dddd'}]
            matcher.add('PHONE_NUMBER', None, pattern)
            pattern = [{'SHAPE': 'ddd'}, {'ORTH': '-', 'OP': '?'},{'SHAPE': 'ddd'},
                    {'ORTH': '-', 'OP': '?'}, {'SHAPE': 'dddd'}]
            matcher.add('PHONE_NUMBER', None, pattern)

            matches = matcher(document)
            toredact += [(document[start:end].text,start,end,'PHONE_NUMBER') for match_id, start, end in matches]

        if args.concept:
            sentences=list(document.sents)
            target = nlp("children")

            sim = [target.similarity(e) for e in sentences]
            sim = np.array(sim)
            maxima = np.where(sim >0.55)
            toredact = [(str(sentences[e]), sentences[e].start_char, sentences[e].end_char, 'CONCEPT') for e in maxima[0]]

        print(toredact)

if __name__ == '__main__':
#    main(url2)
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=str, required=True,
                         help="The directory to be redacted.")
    parser.add_argument("--names", action='store_true')
    parser.add_argument("--dates", action='store_true')
    parser.add_argument("--addresses", action='store_true')
    parser.add_argument("--gender", action='store_true')
    parser.add_argument("--phones", action='store_true')
    parser.add_argument("--concept", type=str, required=True,
                         help="The concept string to be redacted.")

    args = parser.parse_args()
    if args.input:
        main(args)

